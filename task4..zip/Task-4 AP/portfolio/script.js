// Add interactivity later like scroll or form validation
console.log("Portfolio page loaded!");
